import styles from './page.module.css';

export default function Demos() {
  return (
    <div className="content">
      <h1 className={styles.hey}>Hey</h1>
    </div>
  )
}
